<?php

error_reporting(0);

require_once(__DIR__ . '/../deps_loader.php');

rpc_api();
